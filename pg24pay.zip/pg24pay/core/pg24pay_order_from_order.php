<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of veintequatropago_order
 *
 * @author 24-pay
 */
include_once 'country_code_converter.php';
include_once 'pg24pay_sign.php';

class Pg24payOrderFromOrder {
    public $mid;
    public $eshopId;
    public $msTxnId;
    public $amount;
    public $currAlphaCode;
    public $language;
    public $clientId;
    public $firstName;
    public $familyName;
    public $email;
    public $country;
    public $nurl;
    public $rurl;
    public $timestamp;
    public $sign;

    public $debug = true;

    private $signGenerator;

    function __construct($orderId, $link){

        $this->signGenerator = new Pg24paySign();

        $this->mid = $this->signGenerator->mid;
        $this->eshopId = $this->signGenerator->eshopid;

        $objOrder = new Order($orderId);

        $customer = new Customer($objOrder->id_customer);
        $address = new Address($objOrder->id_address_invoice);
        $country = new Country($address->id_country);
        $language = new Language($objOrder->id_lang);
        $currency = new Currency($objOrder->id_currency);

        $this->msTxnId = Cart::getCartIdByOrderId($orderId);

        $this->currAlphaCode = $currency->iso_code;
        $this->language = strtoupper($language->iso_code);

        $this->timestamp = date("Y-m-d H:i:s");
        $this->clientId = str_pad($objOrder->id_customer, 3, "0", STR_PAD_LEFT);
        $this->firstName = $customer->firstname;
        $this->familyName = $customer->lastname;
        $this->email = $customer->email;
        $this->country = $this->convertCountryCodeToIsoA3($country->iso_code);

        $this->amount = number_format($objOrder->total_paid_real, 2, '.', '');

        $this->rurl = $link->getModuleLink('pg24pay','rurl',[]);
        $this->nurl = $link->getModuleLink('pg24pay','nurl',[]);
    }

    private function convertCountryCodeToIsoA3($isoa2code) {
        return convert_country_code_from_isoa2_to_isoa3($isoa2code);
    }

    private function plainText(){
        return $this->mid.$this->amount.$this->currAlphaCode.$this->msTxnId.$this->firstName.$this->familyName.$this->timestamp;
    }

    public function signRequest(){
        $this->sign = $this->signGenerator->getSign($this->plainText());
    }

    public function preview(){

        echo "<pre>";
            echo "PlainText: ".$this->plainText()."\n\r";
            echo "Mid: ".$this->mid."\n\r";
            echo "EshopId: ".$this->eshopId."\n\r";
            echo "MsTxnId: ".$this->msTxnId."\n\r";
            echo "Amount: ".$this->amount."\n\r";
            echo "Currency: ".$this->currAlphaCode."\n\r";
            echo "Language: ".$this->language."\n\r";
            echo "ClientId: ".$this->clientId."\n\r";
            echo "FirstName: ".$this->firstName."\n\r";
            echo "LastName: ".$this->familyName."\n\r";
            echo "Email: ".$this->email."\n\r";
            echo "Country: ".$this->country."\n\r";
            echo "NURL: ".$this->nurl."\n\r";
            echo "RURL: ".$this->rurl."\n\r";
            echo "Timestamp: ".$this->timestamp."\n\r";
            echo "Sign: ".$this->sign."\n\r";
        echo "</pre>";
    }
}
