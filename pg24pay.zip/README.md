# 24payprestashop1_8
24pay plugin for Prestashop ver 1.7.6 + and 8.0.0

Current version 1.0.2

= Released  = [20.07.2023]
= ver 1.0.1 = [25.04.2023]
= ver 1.0.0 = [23.11.2022]

= Last Time Tested [Prestashop ver 8.0.2 and 8.0.3]